from django.apps import AppConfig


class EmailVerificationConfig(AppConfig):
    name = 'verification'
